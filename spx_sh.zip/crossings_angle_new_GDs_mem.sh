###===================
#!/bin/bash
#PBS -l select=1:ncpus=4:mem=24gb:pcmem=6gb -l walltime=20:00:00
#PBS -l cput=25:00:00
#PBS -q high_pri
#PBS -W group_list=mstrout
###-------------------

echo "Node name:"
hostname

cd /extra/abureyanahmed/GD2018
module load python/3.5/3.5.5
python3 $RUN_WITH_PARAM < $LOG_FOLDER/input_$PBS_ARRAY_INDEX.dat > $LOG_FOLDER/output_$PBS_ARRAY_INDEX.dat 2> $LOG_FOLDER/error_$PBS_ARRAY_INDEX.dat

