import numpy as np
import os
from input_functions import *
from collections import OrderedDict

def write_array(arr, file_name):
 file = open(file_name,"w")
 for j in range(len(arr)):
  file.write(str(j+1)+"\t"+str(arr[j])+"\n")
 file.close()


def check_grad_desc_ncr(edge_threshold, folder_name, iterations_small_graph, iterations_large_graph):
 my_inf = 10000000
 #folder_name = "input_angle"
 #folder_name = "../graphs/input18"
 file_names = []
 for name in os.listdir(folder_name):
  if name=='.gml.txt':
   continue
  if name[:4]=='grad':
   continue
  if name[len(name)-4:len(name)]=='.txt':
   file_names.append(name[:len(name)-4])
 #file_names = ["input1", "input2", "input3", "input4", "input5", "input6"]
 #file_names = ['maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration10graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration11graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration13graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration14graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration17graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration18graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration19graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration1graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration20graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration22graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration23graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration25graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration26graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration27graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration28graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration29graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration2graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration30graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration31graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration32graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration34graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration35graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration36graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration38graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration3graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration40graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration44graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration45graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration46graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration47graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration48graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration49graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration4graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration50graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration51graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration55graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration56graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration58graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration59graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration5graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration60graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration61graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration62graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration63graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration64graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration65graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration66graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration67graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration69graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration6graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration70graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration73graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration74graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration75graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration76graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration77graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration78graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration79graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration7graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration80graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration82graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration83graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration84graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration86graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration87graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration88graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration89graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration8graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration91graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration93graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration94graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration95graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration97graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration98graph', 'maxDeg5nodeDegreeExp-2.000000minCommunitySize2maxCommunitySize10communitySizeExp-1.000000avGDegree3iteration9graph']
 #file_names= ['g.14.27', 'g.16.91', 'g.41.36', 'g.48.3', 'g.56.4', 'g.57.29', 'g.60.16']
 #file_names= ['g.11.72', 'g.14.27', 'g.16.91', 'g.21.27', 'g.22.54', 'g.39.4', 'g.41.36', 'g.44.15', 'g.48.3', 'g.56.10', 'g.56.4', 'g.57.29', 'g.60.16', 'g.64.17', 'g.85.8', 'g.90.1', 'g.99.2']
 #file_names= ['g.10.19', 'g.10.79', 'g.11.72', 'g.13.51', 'g.14.27', 'g.16.91', 'g.18.1', 'g.18.22', 'g.20.14', 'g.20.49', 'g.21.27', 'g.22.54', 'g.23.103', 'g.25.55', 'g.30.2', 'g.33.16', 'g.34.9', 'g.35.26', 'g.35.32', 'g.36.17', 'g.39.4', 'g.39.47', 'g.40.19', 'g.41.36', 'g.41.9', 'g.42.15', 'g.44.15', 'g.46.19', 'g.48.3', 'g.53.3', 'g.53.9', 'g.56.10', 'g.56.4', 'g.57.15', 'g.57.29', 'g.60.16', 'g.62.4', 'g.63.0', 'g.63.18', 'g.64.17', 'g.75.0', 'g.85.8', 'g.90.1', 'g.99.2']
 #file_names= ['g.10.19', 'g.10.27', 'g.10.79', 'g.10.80', 'g.10.86', 'g.10.88', 'g.11.72', 'g.13.51', 'g.13.95', 'g.14.27', 'g.14.38', 'g.15.28', 'g.16.91', 'g.17.41', 'g.18.1', 'g.18.22', 'g.18.24', 'g.18.38', 'g.20.14', 'g.20.47', 'g.20.49', 'g.21.1', 'g.21.27', 'g.21.33', 'g.22.54', 'g.22.70', 'g.23.103', 'g.23.115', 'g.23.90', 'g.25.40', 'g.25.55', 'g.28.20', 'g.30.2', 'g.31.34', 'g.31.37', 'g.32.11', 'g.32.21', 'g.33.16', 'g.33.8', 'g.34.9', 'g.35.15', 'g.35.26', 'g.35.32', 'g.36.17', 'g.36.19', 'g.37.8', 'g.39.4', 'g.39.47', 'g.39.53', 'g.40.19', 'g.41.13', 'g.41.2', 'g.41.36', 'g.41.9', 'g.42.15', 'g.42.23', 'g.43.8', 'g.44.15', 'g.44.19', 'g.46.19', 'g.48.3', 'g.53.3', 'g.53.9', 'g.55.13', 'g.55.23', 'g.55.30', 'g.55.6', 'g.55.8', 'g.56.10', 'g.56.2', 'g.56.4', 'g.57.15', 'g.57.27', 'g.57.29', 'g.57.5', 'g.57.8', 'g.57.9', 'g.58.0', 'g.59.14', 'g.60.16', 'g.61.3', 'g.61.31', 'g.61.54', 'g.62.3', 'g.62.4', 'g.63.0', 'g.63.1', 'g.63.18', 'g.64.17', 'g.64.18', 'g.66.8', 'g.70.1', 'g.73.4', 'g.75.0', 'g.75.4', 'g.85.8', 'g.86.5', 'g.90.1', 'g.97.1', 'g.99.2']
 #file_names= ['plantri_graph10', 'plantri_graph11', 'plantri_graph14', 'plantri_graph15', 'plantri_graph33', 'plantri_graph39', 'plantri_graph42', 'plantri_graph44', 'plantri_graph53', 'plantri_graph54', 'plantri_graph63', 'plantri_graph66', 'plantri_graph69', 'plantri_graph72', 'plantri_graph77', 'plantri_graph79', 'plantri_graph84', 'plantri_graph89', 'plantri_graph90', 'plantri_graph92', 'plantri_graph93', 'plantri_graph99']
 #file_names= ['plantri_graph1', 'plantri_graph10', 'plantri_graph100', 'plantri_graph101', 'plantri_graph11', 'plantri_graph12', 'plantri_graph13', 'plantri_graph14', 'plantri_graph15', 'plantri_graph16', 'plantri_graph17', 'plantri_graph18', 'plantri_graph19', 'plantri_graph2', 'plantri_graph20', 'plantri_graph21', 'plantri_graph22', 'plantri_graph23', 'plantri_graph24', 'plantri_graph25', 'plantri_graph26', 'plantri_graph27', 'plantri_graph28', 'plantri_graph29', 'plantri_graph3', 'plantri_graph30', 'plantri_graph32', 'plantri_graph33', 'plantri_graph35', 'plantri_graph36', 'plantri_graph37', 'plantri_graph38', 'plantri_graph39', 'plantri_graph4', 'plantri_graph40', 'plantri_graph41', 'plantri_graph42', 'plantri_graph43', 'plantri_graph44', 'plantri_graph45', 'plantri_graph46', 'plantri_graph47', 'plantri_graph48', 'plantri_graph49', 'plantri_graph5', 'plantri_graph50', 'plantri_graph51', 'plantri_graph52', 'plantri_graph53', 'plantri_graph54', 'plantri_graph55', 'plantri_graph56', 'plantri_graph57', 'plantri_graph58', 'plantri_graph59', 'plantri_graph6', 'plantri_graph60', 'plantri_graph61', 'plantri_graph62', 'plantri_graph63', 'plantri_graph64', 'plantri_graph65', 'plantri_graph66', 'plantri_graph67', 'plantri_graph68', 'plantri_graph69', 'plantri_graph7', 'plantri_graph70', 'plantri_graph71', 'plantri_graph72', 'plantri_graph73', 'plantri_graph74', 'plantri_graph75', 'plantri_graph76', 'plantri_graph77', 'plantri_graph78', 'plantri_graph79', 'plantri_graph8', 'plantri_graph80', 'plantri_graph81', 'plantri_graph82', 'plantri_graph83', 'plantri_graph84', 'plantri_graph85', 'plantri_graph86', 'plantri_graph87', 'plantri_graph88', 'plantri_graph89', 'plantri_graph9', 'plantri_graph90', 'plantri_graph92', 'plantri_graph93', 'plantri_graph94', 'plantri_graph96', 'plantri_graph97', 'plantri_graph98', 'plantri_graph99']
 #file_names= ['grafo10384.99', 'grafo10411.98', 'grafo1101.25', 'grafo11063.92', 'grafo11106.99', 'grafo11135.95', 'grafo11206.91', 'grafo1946.31', 'grafo1974.23', 'grafo2692.85', 'grafo3127.57', 'grafo3276.49', 'grafo3694.41', 'grafo3714.52', 'grafo3833.55', 'grafo3975.38', 'grafo4035.40', 'grafo4493.76', 'grafo4654.74', 'grafo4760.55', 'grafo4926.78', 'grafo4948.78', 'grafo5421.34', 'grafo5637.41', 'grafo5694.45', 'grafo5901.35', 'grafo5975.45', 'grafo6081.42', 'grafo6336.43', 'grafo7178.37', 'grafo7296.42', 'grafo7482.41', 'grafo7498.41', 'grafo7499.92', 'grafo7549.38', 'grafo7864.75', 'grafo8127.78', 'grafo8176.86', 'grafo8386.73', 'grafo8534.84', 'grafo8942.96', 'grafo8955.96', 'grafo9713.73', 'grafo9860.40']

 W_start = 1
 W_end = 2

 #K_start = -5
 #K_end = 6

 K_start = -5
 K_end = 5

 NUM_RUNS = 15
 NUM_ITERATIONS = iterations_small_graph
 #job_name_prefix = 'edge_crossings'
 GD_OPTIONS = ['VANILLA', 'MOMENTUM', 'NESTEROV', 'ADAGRAD', 'RMSPROP', 'ADAM']
 alpha_arr = ['1e-3', '1e-3', '1e-3', '1e-1', '1e-1', '1e-1'] # learning rate

 min_ncr = []
 file_completed = []

 #for n in range(2):
 for n in range(1):
  for W in range(W_start, W_end):
   for i in range(len(file_names)):
    min_ncr.append(my_inf)
    dummy, coord_list, edge_list = take_input(folder_name + '/' + file_names[i]+'.txt')
    count_jobs_for_one_input = 0
    for s in range(len(GD_OPTIONS)):
     if len(edge_list)>edge_threshold:
      NUM_ITERATIONS = iterations_large_graph
      K_start = 1
      K_end = 2
      layout = ['neato', 'sfdp', 'random']
      NUM_RUNS = len(layout)
      layout_number = ['0', '0', '0']
     else:
      NUM_ITERATIONS = iterations_small_graph
      K_start = -5
      K_end = 5
      layout = ['neato', 'neato', 'neato', 'neato', 'neato', 'sfdp', 'sfdp', 'sfdp', 'sfdp', 'sfdp', 'random', 'random', 'random', 'random', 'random']
      NUM_RUNS = len(layout)
      layout_number = ['0', '1', '2', '3', '4', '0', '1', '2', '3', '4', '0', '1', '2', '3', '4']
     K_start_str = str(K_start)
     if K_start<0:
      K_start_str = 'N'+str(-K_start)
     K_end_str = str(K_end)
     if K_end<0:
      K_end_str = 'N'+str(-K_end)
     for r in range(0,NUM_RUNS):
      file_ext = 'W_'+str(W)+'_NORM_'+str(n)+'_K_'+K_start_str+'_'+K_end_str+'_STRAT_'+GD_OPTIONS[s]+'_'+layout[r]+'_'+layout_number[r]
      if not os.path.exists(folder_name + '/' + file_names[i] + '_ncr_'+file_ext+'.npy'):
       #print(folder_name + '/' + file_names[i] + '_ncr_'+file_ext+'.npy not found!')
       continue
      count_jobs_for_one_input += 1
      MIN_NCR = np.load(folder_name + '/' + file_names[i] + '_ncr_'+file_ext+'.npy')
      #X_new = np.load(folder_name + '/' + file_names[i] + '_xy_'+file_ext+'.npy')
      for K in range(K_start,K_end):
       for it in range(NUM_ITERATIONS):
        if min_ncr[i]>MIN_NCR[W-W_start][K-K_start][it]:
         min_ncr[i] = MIN_NCR[W-W_start][K-K_start][it]
         #write_as_txt(folder_name + '/grad_desc' + str(i+1) + '.txt', edge_list, X_new[W-W_start][K-K_start][it][:,0], X_new[W-W_start][K-K_start][it][:,1])
         #txt_to_json(folder_name + '/grad_desc' + str(i+1) + '.txt', folder_name + '/grad_desc' + str(i+1) + '.json')
    #print('count_jobs_for_one_input:',count_jobs_for_one_input)
    if count_jobs_for_one_input == 90:
     file_completed.append(file_names[i])
   print('file_completed:',file_completed)

 write_array(min_ncr, folder_name + '/grad_desc_min_ncr.txt')
 incomplete_graphs = []
 if my_inf in min_ncr:
  for i in range(len(min_ncr)):
   if my_inf == min_ncr[i]:
    incomplete_graphs.append(i)
 #for i in range(len(incomplete_graphs)):
 # print(file_names[incomplete_graphs[i]])
 dict_ncr = {}
 for i in range(len(min_ncr)):
  if not min_ncr[i] == my_inf:
   dict_ncr[file_names[i]] = min_ncr[i]
 ord_dict_ncr = OrderedDict(sorted(dict_ncr.items()))
 print(ord_dict_ncr.values())
 min_ncr.sort()
 #min_ncr = min_ncr[:85]
 #min_ncr = min_ncr[:32]
 #min_ncr = min_ncr[:79]
 print(min_ncr)
 print(sum(min_ncr) / len(min_ncr))
 print(min_ncr[0], min_ncr[int(len(min_ncr)*.25)], min_ncr[int(len(min_ncr)*.50)], min_ncr[int(len(min_ncr)*.75)], min_ncr[len(min_ncr)-1])
 return min_ncr


#check_grad_desc(16, 100)
#check_grad_desc(10, 100)

#check_grad_desc(11, 100, '../graphs/input_angle/')
#check_grad_desc(16, 100, '../graphs/input_angle_17/')
#check_grad_desc_ncr(11, 100, '../graphs/input_crossing/')

#check_grad_desc_ncr(100, '../graphs/community')
#check_grad_desc_ncr(100, '../graphs/north')
#check_grad_desc_ncr(100, '../graphs/plantri')
#check_grad_desc_ncr(100, '../graphs/rome')

def check_all():
 arr = []
 #arr.extend(check_grad_desc_ncr(200, '../graphs/community_new_GDs', 30, 2))
 #arr.extend(check_grad_desc_ncr(200, '../graphs/north_pbs_arr', 30, 2))
 #arr.extend(check_grad_desc_ncr(200, '../graphs/plantri_pbs_arr', 30, 2))
 #arr.extend(check_grad_desc_ncr(200, '../graphs/rome_pbs_arr', 30, 2))
 arr.extend(check_grad_desc_ncr(200, 'crossing_min_random_drawing/rome_pbs_arr', 30, 2))
 #arr.sort()
 #print(sum(arr) / len(arr))
 #print(arr[0], arr[int(len(arr)*.25)], arr[int(len(arr)*.50)], arr[int(len(arr)*.75)], arr[len(arr)-1])

check_all()


