#number_of_drawings = 100
#number_of_tasks = 10
number_of_drawings = 50
number_of_tasks = 10
drawings_per_task = number_of_drawings/number_of_tasks
number_of_graphs = 16

f = open('qsub_commands_layout_statistics.sh','w')
for t in range(number_of_tasks):
 drawing_start = t*drawings_per_task + 1
 f.write('export folder_name=input18\n')
 f.write('export number_of_graphs='+str(number_of_graphs)+'\n')
 f.write('export number_of_drawings='+str(drawings_per_task)+'\n')
 f.write('export drawing_start='+str(drawing_start)+'\n')
# f.write('qsub -N layout_statistics_'+str(number_of_tasks+1)+' -o log_files/layout_statistics_'+str(drawing_start)+'_'+str(drawings_per_task+drawing_start)+'.out -e log_files/layout_statistics_'+str(drawing_start)+'_'+str(drawings_per_task+drawing_start)+'.err -V layout_statistics.sh\n')
 f.write('./layout_statistics.sh&\n')
f.close()

