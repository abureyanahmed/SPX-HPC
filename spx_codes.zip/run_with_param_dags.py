import subprocess

CODE_FILE = input()
NORMALIZE = input()
FILE_NAME_PREFIX = input()
OUTPUT_FOLDER = input()

p = subprocess.Popen(['python3', CODE_FILE, NORMALIZE, FILE_NAME_PREFIX, OUTPUT_FOLDER], stdout=subprocess.PIPE)
output, error = p.communicate()
print(output)

