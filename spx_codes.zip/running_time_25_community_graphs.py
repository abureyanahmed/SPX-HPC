folder_name = "log_files_community_angle_2/"
time_arr = []
for i in range(1, 480+1):
#for i in range(1, 1+1):
  file_name = folder_name + "output_"+str(i)+".dat"
  f = open(file_name, 'r')
  s = str(f.readline())
  arr = s.split("total_gradient_descent_time: ")
  if len(arr)!=2:continue
  arr = arr[1].split("total_penalties_after_grad_desc_time: ")
  if len(arr)!=2:continue
  time_arr.append(float(arr[0][:len(arr[0])-2]))
time_arr.sort()
print(time_arr[0], time_arr[len(time_arr)//2], time_arr[len(time_arr)-1])

