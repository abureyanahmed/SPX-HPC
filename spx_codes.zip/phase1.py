import sys
import json
if len(sys.argv) < 2:
	print('Usage: python3 phase1.py input_file.txt')
	quit()

input_file = sys.argv[1]
#graph_property = 'weighted'
graph_property = 'unweighted'
file = open(input_file,"r")
print("File name: "+input_file)
graph = json.loads(file.read())
print(graph)

n = len(graph['nodes'])
matrix = [[0] * n for i in range(n)]

for e in graph['edges']:
        matrix[e['target']][e['source']] = matrix[e['source']][e['target']] = 1

print(matrix)

# play with the math of https://cseweb.ucsd.edu/~lvdmaaten/workshops/nips2010/papers/bennett.pdf
print('Two points of line A are a and c')
print('Two points of line B are b and d')
a = {}
tmp = [float(i) for i in input('ax ay?').split()]
a['x']=tmp[0]
a['y']=tmp[1]
print(a)
b = {}
tmp = [float(i) for i in input('bx by?').split()]
b['x']=tmp[0]
b['y']=tmp[1]
print(b)
c = {}
tmp = [float(i) for i in input('cx cy?').split()]
c['x']=tmp[0]
c['y']=tmp[1]
print(c)
d = {}
tmp = [float(i) for i in input('dx dy?').split()]
d['x']=tmp[0]
d['y']=tmp[1]
print(d)

import numpy as np

tmp = [float(i) for i in input('ux uy?').split()]
u = np.array([tmp[0], tmp[1]])
print(u)

import numpy as np
A = np.array([[a['x'],a['y']], [c['x'],c['y']]])
print(np.dot(A, u))

