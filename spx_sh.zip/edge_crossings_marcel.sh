###===================
#!/bin/bash
#PBS -l select=1:ncpus=1:mem=6gb:pcmem=6gb -l walltime=05:00:00
#PBS -l cput=05:00:00
#PBS -q windfall
#PBS -W group_list=kobourov
###-------------------

echo "Node name:"
hostname

cd /extra/abureyanahmed/GD2018
module load python/3.5/3.5.5
python3 main_jacob_new_GDs.py $OUTPUT_FOLDER $FILE_NAME_PREFIX $W_start $W_end $K_start $K_end $USE_INITIAL $num_iterations $NORMALIZE $OUTPUT_FILE_EXT $STRATEGY $ALPHA $GRADIENT_DESCENT_ITERATIONS

