import json
import sys
from edge_crossing import *
from input_functions import *
from utils import *
import time

# this function used to find out whether two vertices share or not
# but now it is redundant as the computation is already placed in edgecrossing.py inside the doIntersect function
def share_vertex(e1, e2):
 if e1[0]==e2[0] or e1[0]==e2[1]:
  return True
 if e1[1]==e2[0] or e1[1]==e2[1]:
  return True
 return False


def number_of_intersections(file_name):
 #print(file_name)
 if file_name.endswith('.dot'):
  node_coords, edge_list = parse_dot_file(file_name)
 elif file_name.endswith('.txt'):
  n, node_coords, edge_list = take_input(file_name)
 count = 0
 for i in range(len(edge_list)):
  for j in range(i+1,len(edge_list)):
   edge1 = edge_list[i]
   edge2 = edge_list[j]
   #if not share_vertex(edge1, edge2):
   if(doIntersect(node_coords[edge1[0]][0], node_coords[edge1[0]][1], node_coords[edge1[1]][0], node_coords[edge1[1]][1], node_coords[edge2[0]][0], node_coords[edge2[0]][1], node_coords[edge2[1]][0], node_coords[edge2[1]][1])):
    count = count + 1
    #print(str(edge1)+" intersects "+str(edge2))
 return count

def all_graph_crossing_numbers(algo_name, folder_name, number_of_graphs, drawing):
 arr = []
 for i in range(1,number_of_graphs+1):
 #for i in range(1,3):
  #print(folder_name+'/'+algo_name+'_layout'+str(i)+'.dot')
  #print('number of intersections:')
  #print(number_of_intersections(folder_name+'/'+algo_name+'_layout'+str(i)+'.dot'))
  if drawing!=-1:
   arr.append(number_of_intersections(folder_name+'/'+algo_name+'_layout'+str(i)+'_drawing_'+str(drawing)+'.dot'))
  else:
   arr.append(number_of_intersections(folder_name+'/input'+str(i)+'.txt'))
 return arr

def all_drawings_crossings(algo_name, folder_name, number_of_graphs, number_of_drawings, drawing_start):
 arr = []
 for i in range(drawing_start, number_of_drawings+drawing_start):
  arr.append(all_graph_crossing_numbers(algo_name, folder_name, number_of_graphs, i))
 return arr

def all_graph_min_angle(algo_name, folder_name, number_of_graphs, drawing):
 arr = []
 for i in range(1,number_of_graphs+1):
  if drawing!=-1:
   arr.append(min_angle(folder_name+'/'+algo_name+'_layout'+str(i)+'_drawing_'+str(drawing)+'.dot'))
  else:
   arr.append(min_angle(folder_name+'/input'+str(i)+'.txt'))
 return arr

def all_drawings_min_angles(algo_name, folder_name, number_of_graphs, number_of_drawings, drawing_start):
 arr = []
 for i in range(drawing_start, number_of_drawings+drawing_start):
  arr.append(all_graph_min_angle(algo_name, folder_name, number_of_graphs, i))
 return arr

def usage():
 if len(sys.argv)<5:
  print('usage:python layout_statistics.py folder_name number_of_graphs number_of_drawings drawing_start')
  quit()
 else:
  return sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])

#file = open('sfdp_crossings2.txt','w')
#file.write(json.dumps(all_graph_crossing_numbers('sfdp', 'erdos_renyi2')))
#file.close()

#file = open('neato_crossings2.txt','w')
#file.write(json.dumps(all_graph_crossing_numbers('neato', 'erdos_renyi2')))
#file.close()

#print(json.dumps(number_of_intersections('test_graphs/sfdp_layout_complete5.dot')))

folder_name, number_of_graphs, number_of_drawings, drawing_start = usage()

#start_time = time.time()
#file = open(folder_name+'/'+'sfdp_crossings'+str(drawing_start)+'_'+str(number_of_drawings+drawing_start)+'.txt','w')
#file.write(json.dumps(all_drawings_crossings('sfdp', folder_name, number_of_graphs, number_of_drawings, drawing_start)))
#file.close()
#print('Time to complete all_drawings_crossings sfdp: ' + str((time.time() - start_time)) + ' seconds')

#start_time = time.time()
#file = open(folder_name+'/'+'neato_crossings'+str(drawing_start)+'_'+str(number_of_drawings+drawing_start)+'.txt','w')
#file.write(json.dumps(all_drawings_crossings('neato', folder_name, number_of_graphs, number_of_drawings, drawing_start)))
#file.close()
#print('Time to complete all_drawings_crossings neato: ' + str((time.time() - start_time)) + ' seconds')

#start_time = time.time()
#file = open(folder_name+'/'+'input_crossings.txt','w')
#file.write(json.dumps(all_graph_crossing_numbers('', folder_name, number_of_graphs, -1)))
#file.close()
#print('Time to complete input crossings: ' + str((time.time() - start_time)) + ' seconds')

start_time = time.time()
file = open(folder_name+'/'+'sfdp_min_angles'+str(drawing_start)+'_'+str(number_of_drawings+drawing_start)+'.txt','w')
file.write(json.dumps(all_drawings_min_angles('sfdp', folder_name, number_of_graphs, number_of_drawings, drawing_start)))
file.close()
print('Time to complete all_drawings_min_angles sfdp: ' + str((time.time() - start_time)) + ' seconds')

start_time = time.time()
file = open(folder_name+'/'+'neato_min_angles'+str(drawing_start)+'_'+str(number_of_drawings+drawing_start)+'.txt','w')
file.write(json.dumps(all_drawings_min_angles('neato', folder_name, number_of_graphs, number_of_drawings, drawing_start)))
file.close()
print('Time to complete all_drawings_min_angles neato: ' + str((time.time() - start_time)) + ' seconds')

#start_time = time.time()
#file = open(folder_name+'/'+'input_min_angles.txt','w')
#file.write(json.dumps(all_graph_min_angle('', folder_name, number_of_graphs, -1)))
#file.close()
#print('Time to complete input min_angles: ' + str((time.time() - start_time)) + ' seconds')

