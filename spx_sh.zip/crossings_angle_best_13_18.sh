###===================
#!/bin/bash
#PBS -l select=1:ncpus=1:mem=6gb:pcmem=6gb -l walltime=20:00:00
#PBS -l cput=25:00:00
#PBS -q standard
#PBS -W group_list=mstrout
###-------------------

echo "Node name:"
hostname

cd /extra/abureyanahmed/GD2018
module load python/3.5/3.5.5
python3 check_store_X.py 13 input_angle_13_18 1 30 31 5


