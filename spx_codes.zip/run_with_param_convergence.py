import subprocess

CODE_FILE = 'main_angle_stress_maj_convergence.py'
GD_OPTION = input()
ALPHA = input()

p = subprocess.Popen(['python3', CODE_FILE, GD_OPTION, ALPHA], stdout=subprocess.PIPE)
output, error = p.communicate()
print(output)

