import subprocess

CODE_FILE = input()
OUTPUT_FOLDER = input()
FILE_NAME_PREFIX = input()
W_start = input()
W_end = input()
K_start = input()
K_end = input()
USE_INITIAL = input()
num_iterations = input()
NORMALIZE = input()
OUTPUT_FILE_EXT = input()
STRATEGY = input()
ALPHA = input()
GRADIENT_DESCENT_ITERATIONS = input()
EDGE_PAIR_SAMPLE_K = input()

p = subprocess.Popen(['python3', CODE_FILE, OUTPUT_FOLDER, FILE_NAME_PREFIX, W_start, W_end, K_start, K_end, USE_INITIAL, num_iterations, NORMALIZE, OUTPUT_FILE_EXT, STRATEGY, ALPHA, GRADIENT_DESCENT_ITERATIONS, EDGE_PAIR_SAMPLE_K], stdout=subprocess.PIPE)
output, error = p.communicate()
print(output)

