#import main_angles_reyan_so
import main_jacob

optimizer_jacob("input_angle", "input1", 1, 2, 0, 1, 3, 6, 0)

