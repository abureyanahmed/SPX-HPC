import math
from iterators import *
from input_functions import *


def jacob_write_angle(folder_name, file_names, i, job_name_prefix, log_folder, layout_ext, count_qsub_commands):
 #f = open('qsub_commands_new_GDs.sh','a')
 f = open(log_folder+'/input_'+str(count_qsub_commands+1)+'.dat','w')
 f.write('main_hard_constraints_undirected.py\n')
 f.write('0\n')
 f.write(file_names[i]+'\n')
 f.write(folder_name+'\n')
 return [0, 0, 0, 0]


def create_qsub_variable_param(edge_threshold, folder_name, job_name_prefix, log_folder, pbs_script_name_small_graph):
 #f = open('qsub_commands_new_GDs.sh','w')
 #f.close()

 #folder_name = "input_angle"
 #folder_name = "../graphs/input18"

 if folder_name=="dags_undirected" or folder_name=="dags_up_bound_1":
  file_names = []
  nodes = [5, 10, 15, 20, 25]
  for n in nodes:
   m = 2*n
   file_names.append('graph_n_'+str(n)+'_m_'+str(m))
  heights = [2, 3, 4, 5, 6]
  for n in heights:
   file_names.append('tree_h_'+str(n))

 if folder_name=="small_30_dags":
  file_names = []
  nodes = range(5,35)
  for n in nodes:
   m = 2*n
   file_names.append('graph_n_'+str(n)+'_m_'+str(m))

 if folder_name=="small_3_dags_undirected" or folder_name=="small_3_dags_2":
  file_names = []
  nodes = [5-1+9, 5-1+12, 5-1+28]
  for n in nodes:
   m = 2*n
   file_names.append('graph_n_'+str(n)+'_m_'+str(m))

 W_start = 1
 W_end = 2

 #K_start = -5
 #K_end = 6

 K_start = -5
 K_end = 5

 NUM_RUNS = 15
 #job_name_prefix = 'edge_crossings'
 GD_OPTIONS = ['VANILLA', 'MOMENTUM', 'NESTEROV', 'ADAGRAD', 'RMSPROP', 'ADAM']
 alpha_arr = ['1e-3', '1e-3', '1e-3', '1e-1', '1e-1', '1e-1'] # learning rate

 pbs_script_name = pbs_script_name_small_graph

 count_qsub_commands = 0

 #for n in range(2):
 for n in range(1):
  for W in range(W_start, W_end):
   for i in range(len(file_names)):
    res_arr = jacob_write_angle(folder_name, file_names, i, job_name_prefix, log_folder, '', count_qsub_commands)
    count_qsub_commands += 1
 print('count_qsub_commands:',count_qsub_commands)
 f = open('qsub_commands_new_GDs.sh','w')
 f.write('qsub -J 1-'+str(count_qsub_commands)+' -N ' + job_name_prefix+ ' -o ' + log_folder  + '/' + job_name_prefix +'.out -e ' + log_folder  + '/' + job_name_prefix +'.err -V ' + pbs_script_name + '\n')
 f.close()
 #return NUMBER_OF_CROSSINGS, COST_FUNCTIONS, X_new, init_X


#create_qsub_variable_param(100, "input_angle_stress_maj", 'crossings_angle', 'log_files_stress_maj', 'crossings_angle_more_layouts.sh', 'dummy', 30, 2, 100, 2)
#create_qsub_variable_param(100, "input_angle_bin_sampling", 'crossings_angle', 'log_files_bin_sampling', 'crossings_angle_more_layouts.sh', 'crossings_angle_new_GDs_mem.sh', 30, 30, 100, 100)
#create_qsub_variable_param(100, "dags_undirected", 'upward', 'log_files_dags_undirected', 'crossings_angle_more_layouts.sh')
#create_qsub_variable_param(100, "small_30_dags", 'upward', 'log_files_small_30_dags', 'crossings_angle_more_layouts.sh')
#create_qsub_variable_param(100, "dags_up_bound_1", 'upward', 'log_files_dags_up_bound_1', 'crossings_angle_more_layouts.sh')
#create_qsub_variable_param(100, "small_3_dags_undirected", 'upward', 'log_files_small_3_dags_undirected', 'crossings_angle_more_layouts.sh')
create_qsub_variable_param(100, "small_3_dags_2", 'upward', 'log_files_small_3_dags_2', 'crossings_angle_more_layouts.sh')


