###===================
#!/bin/bash
#PBS -l select=1:ncpus=4:mem=24gb:pcmem=6gb -l walltime=30:00:00
#PBS -l cput=35:00:00
#PBS -q standard
#PBS -W group_list=mstrout
###-------------------

echo "Node name:"
hostname

cd /extra/abureyanahmed/GD2018
module load python/3.5/3.5.5
python3 run_with_param.py < log_files_12_18/input_$PBS_ARRAY_INDEX.dat > log_files_12_18/output_$PBS_ARRAY_INDEX.dat 2> log_files_12_18/error_$PBS_ARRAY_INDEX.dat


