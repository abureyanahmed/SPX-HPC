import json
import matplotlib.pyplot as plt

def merge_data(file_name_prefix):
 #folder_name = 'input'
 folder_name = 'input18'
 #number_of_drawings = 100
 number_of_drawings = 50
 number_of_tasks = 10
 drawings_per_task = number_of_drawings/number_of_tasks
 merged_data = []
 for t in range(number_of_tasks):
  drawing_start = t*drawings_per_task + 1
  file_name = folder_name+'/'+file_name_prefix+str(int(drawing_start))+'_'+str(int(drawings_per_task+drawing_start))+'.txt'
  with open(file_name) as f:
   data = json.load(f)
  for i in range(len(data)):
   merged_data.append(data[i])
 file = open(folder_name+'/'+file_name_prefix+'.txt','w')
 file.write(json.dumps(merged_data))
 file.close()

#merge_data('sfdp_crossings')
#merge_data('neato_crossings')
merge_data('sfdp_min_angles')
merge_data('neato_min_angles')

