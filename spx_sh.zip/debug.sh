###===================
#!/bin/bash
#PBS -l select=1:ncpus=1:mem=6gb:pcmem=6gb -l walltime=00:05:00
#PBS -q debug
#PBS -W group_list=mstrout
###-------------------

cd /extra/abureyanahmed/GD2018
module load python/3.5

python3 $RUN_WITH_PARAM < $LOG_FOLDER/input_$PBS_ARRAY_INDEX.dat > $LOG_FOLDER/output_$PBS_ARRAY_INDEX.dat 2> $LOG_FOLDER/error_$PBS_ARRAY_INDEX.dat


