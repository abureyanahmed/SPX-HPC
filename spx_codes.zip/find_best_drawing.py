import json
import matplotlib.pyplot as plt

my_inf = 1000000000
fig_number = 0

def plot_data_from_file(file_name):
 global my_inf, fig_number
 with open(file_name) as f:
  data = json.load(f)
 #print('length of data:'+str(len(data)))
 #print('length of data row:'+str(len(data[0])))
 min_property = [my_inf for i in range(len(data[0]))]
 max_property = [-1 for i in range(len(data[0]))]
 min_index = [0 for i in range(len(data[0]))]
 max_index = [0 for i in range(len(data[0]))]
 for i in range(len(data)):
  for j in range(len(data[0])):
   if data[i][j]<min_property[j]:
    min_property[j]=data[i][j]
    min_index[j] = i
   if data[i][j]>max_property[j]:
    max_property[j]=data[i][j]
    max_index[j] = i

 return max_property, max_index

with open('input/input_min_angles.txt') as f:
 init_data = json.load(f)

neato_property, neato_index = plot_data_from_file('input/neato_min_angles.txt')
sfdp_property, sfdp_index = plot_data_from_file('input/sfdp_min_angles.txt')

print(neato_property)

neato_score = 0
sfdp_score = 0
neato_sfdp_score = 0
neato_sfdp_input_score = 0
arizona_anglers_score = 0
neato_sfdp_input_AA_score = 0
coffeeVM_score = 0
aa_input_score = 0

arizona_anglers_data = [48, 30, 78, 40, 28, 36, 3, 1, 7, 4, 5, 0, 2, 2, 0, 0]
coffeeVM_data = [90, 88, 90, 90, 80, 90, 57, 85, 60, 21, 47, 36, 25, 34, 21, 20]

for i in range(len(arizona_anglers_data)):
 neato_score = neato_score + neato_property[i]
 sfdp_score = sfdp_score + sfdp_property[i]
 neato_sfdp_score = neato_sfdp_score + max(neato_property[i], sfdp_property[i])
 neato_sfdp_input_score = neato_sfdp_input_score + max(neato_property[i], sfdp_property[i] + init_data[i])
 arizona_anglers_score = arizona_anglers_score + arizona_anglers_data[i]
 neato_sfdp_input_AA_score = neato_sfdp_input_AA_score + max(neato_property[i], sfdp_property[i] + init_data[i] + arizona_anglers_data[i])
 coffeeVM_score = coffeeVM_score + coffeeVM_data[i]
 aa_input_score = aa_input_score + max(arizona_anglers_data[i], init_data[i])

print('neato_score: '+str(neato_score))
print('sfdp_score: '+str(sfdp_score))
print('neato_sfdp_score: '+str(neato_sfdp_score))
print('neato_sfdp_input_score: '+str(neato_sfdp_input_score))
print('arizona_anglers_score: '+str(arizona_anglers_score))
print('neato_sfdp_input_AA_score: '+str(neato_sfdp_input_AA_score))
print('coffeeVM_score: '+str(coffeeVM_score))
print('aa_input_score: '+str(aa_input_score))

