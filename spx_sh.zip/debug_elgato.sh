###===================
#!/bin/bash
#PBS -l select=1:ncpus=1:mem=4gb:pcmem=4gb -l walltime=00:05:00
#PBS -q debug
#PBS -W group_list=mstrout
###-------------------

cd /extra/abureyanahmed/GD2018
module load python/3.5

python3 main_angle_variable_k.py input_angle_bin_sampling input1 1 2 1 2 run_neato_input1_0.dot 2 0 test_stress_maj VANILLA 1e-3 2

