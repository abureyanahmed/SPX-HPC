###===================
#!/bin/bash
#PBS -l select=1:ncpus=28:mem=168gb:pcmem=6gb -l walltime=06:00:00
#PBS -l cput=168:00:00
#PBS -q standard
#PBS -W group_list=kobourov
###-------------------

echo "Node name:"
hostname

cd /extra/abureyanahmed/GD2018
module load python/3.5/3.5.5
python3 main_angles_reyan_import.py

