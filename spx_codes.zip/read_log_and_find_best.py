#f = open('log_files_10_18/compute_best.out', 'r')
#f = open('input_angle_13_18/print_log.txt', 'r')
f = open('input_angle_12_18/print_log.txt', 'r')
s = f.read()
s = s.split('Minimum Angle: ')
s = s[1:]
m = -1
for x in s:
 x = x.split()
 x = x[0]
 if float(x)==90:
  continue
 if float(x)>m:
  m = float(x)

print(m)

