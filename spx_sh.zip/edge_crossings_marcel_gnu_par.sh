###===================
#!/bin/bash
#PBS -l select=1:ncpus=28:mem=168gb:pcmem=6gb -l walltime=10:00:00
#PBS -l cput=280:00:00
#PBS -q windfall
#PBS -W group_list=mstrout
###-------------------

echo "Node name:"
hostname

cd /extra/abureyanahmed/GD2018
module load python/3.5/3.5.5
module load parallel

seq 8001 8002 | parallel python3 run_with_param.py < log_files_rome_pbs_arr/input_{}.dat > log_files_rome_pbs_arr/output_{}.dat 2> log_files_rome_pbs_arr/error_{}.dat

