for i in range (0,1000000):
	print(i)	

