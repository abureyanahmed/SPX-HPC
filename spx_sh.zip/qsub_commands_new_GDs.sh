qsub -J 1-3 -N upward -o log_files_small_3_dags_2/upward.out -e log_files_small_3_dags_2/upward.err -V crossings_angle_more_layouts.sh
