###===================
#!/bin/bash
#PBS -l select=1:ncpus=4:mem=24gb:pcmem=6gb -l walltime=100:00:00
#PBS -l cput=200:00:00
#PBS -q high_pri
#PBS -W group_list=mstrout
###-------------------

echo "Node name:"
hostname

cd /extra/abureyanahmed/GD2018
module load python/3.5/3.5.5
python3 main_jacob_angle_simple_gradient.py $OUTPUT_FOLDER $FILE_NAME_PREFIX $W_start $W_end $K_start $K_end $NUM_RUNS $num_iterations $NORMALIZE $OUTPUT_FILE_EXT


