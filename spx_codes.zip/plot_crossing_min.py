import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig_count = 1

def generate_plot(data, number_of_levels, output_file_path):
 global fig_count
 init_levels = 2
 size = len(number_of_levels)
 plt.figure(fig_count)
 fig_count = fig_count + 1
 bp = plt.boxplot(data, 0, '', whis=1000, patch_artist=True)
 #plt.title("BU, TD, HY, min(BU, TD), min(BU, TD, HY) for "+name_of_graph_class[cl])
 plt.xticks(range(1,len(number_of_levels)+1), number_of_levels)
 plt.xlabel('Levels', fontsize=20)
 plt.ylabel('Time (seconds)', fontsize=20)
 #plt.ylim(-500,10500)
 plt.tick_params(axis='x', labelsize=16)
 plt.tick_params(axis='y', labelsize=16)
 plt.show()
 plt.savefig(output_file_path, bbox_inches='tight')
 plt.close()

generate_plot([[1,2,3], [2, 4, 5], [2,3,4]], [2,3,4,5], './test.png')

