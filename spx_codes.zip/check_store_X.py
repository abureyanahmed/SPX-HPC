import numpy as np
import os
from input_functions import *
from edge_crossing import *
import random

def find_min_angle(G, X):
 #edge_list = G.edges()
 #m = len(edge_list)
 edge_list = []
 for e in G.edges():
  u, v = e
  tmp = []
  tmp.append(u)
  tmp.append(v)
  edge_list.append(tmp)
 m = len(edge_list)
 # for every edge in the graph
 # draw a line joining the endpoints
 for i in range(0,m):
  i1, i2 = getNodesforEdge(i, edge_list)
  A = np.zeros((2,2))

  A[0,:] = X[i1, :]
  A[1,:] = X[i2, :]
  #plt.plot(A[:,0] , A[:,1], color='blue')

 num_intersections = 0
 min_angle = math.pi/2.0

 print("Number of edges: ", m)
 print_log("Number of edges: " + str(m))

 # loop through all edge pairs
 for i in range(0,m):
  for j in range(i+1,m):

   A,B = getEdgePairAsMatrix(X,i,j,edge_list)
   # doIntersect(x11, y11, x12, y12, x21, y21, x22, y22)
   if(doIntersect(A[0][0], A[0][1], A[1][0], A[1][1], B[0][0], B[0][1], B[1][0], B[1][1])):

    # print A
    # print B
    # print i
    # print j
    x_pt, y_pt = getIntersection(A[0][0], A[0][1], A[1][0], A[1][1], B[0][0], B[0][1], B[1][0], B[1][1])
    theta = getAngleLineSeg(A[0][0], A[0][1], B[0][0], B[0][1], x_pt, y_pt)
    if theta > math.pi/2.0:
     theta = math.pi - theta
    if theta < min_angle:
     min_angle = theta

    num_intersections += 1

 print("Number of Edge Crossings: ", num_intersections)
 print("Minimum Angle: ", to_deg(min_angle))
 print_log("Number of Edge Crossings: " + str(num_intersections))
 print_log("Minimum Angle: " + str(to_deg(min_angle)))
 return to_deg(min_angle)

#This function returns the nodes of an edge given its index in the edge list
def getNodesforEdge(index, edge_list):
        #print(index)
        #print(edge_list)
        #print('type(edge_list)')
        #print(type(edge_list))
        #print('type(edge_list[index])')
        #print(type(edge_list[index]))
        #print(str(edge_list[index]))
        #print(str(edge_list[index][0]))
        return edge_list[index][0], edge_list[index][1]


# This function extracts the edge pair in the form of matrices
# Returns two matrices A and B
# A contains [a1x, a1y; a2x a2y]
# B contains [b1x, b1y; b2x b2y]
def getEdgePairAsMatrix(X,i,j,edge_list):
        A = np.zeros((2,2))
        B = np.zeros((2,2))

        i1, i2 = getNodesforEdge(i,edge_list)
        j1, j2 = getNodesforEdge(j,edge_list)

        A[0,:] = X[i1, :]
        A[1,:] = X[i2, :]

        B[0,:] = X[j1, :]
        B[1,:] = X[j2, :]

        return A,B


def write_array(arr, file_name):
 file = open(file_name,"w")
 for j in range(len(arr)):
  file.write(str(j+1)+"\t"+str(arr[j])+"\n")
 file.close()

def check_grad_desc(number_of_inputs_start, number_of_inputs_end, edge_threshold, folder_name, iterations_small_graph, iterations_large_graph, gd_iter_small_graph, gd_iter_large_graph, sample_param_1, sample_param_2):
 #folder_name = "input_angle"
 #folder_name = "../graphs/input18"
 file_names = []
 for i in range(number_of_inputs_start, number_of_inputs_end):
  file_names.append("input"+str(i+1))
 #file_names = ["input1", "input2", "input3", "input4", "input5", "input6"]

 W_start = 1
 W_end = 2

 #K_start = -5
 #K_end = 6

 K_start = -5
 K_end = 5

 NUM_RUNS = 15
 NUM_ITERATIONS = iterations_small_graph
 GRADIENT_DESCENT_ITERATIONS = gd_iter_small_graph
 #job_name_prefix = 'edge_crossings'
 GD_OPTIONS = ['VANILLA', 'MOMENTUM', 'NESTEROV', 'ADAGRAD', 'RMSPROP', 'ADAM']
 #GD_OPTIONS = ['ADAM']
 alpha_arr = ['1e-3', '1e-3', '1e-3', '1e-1', '1e-1', '1e-1'] # learning rate

 max_min_angle = []

 #for n in range(2):
 for n in range(1):
  for W in range(W_start, W_end):
   for i in range(len(file_names)):
    max_min_angle.append(-1)
    dummy, coord_list, edge_list = take_input(folder_name + '/' + file_names[i]+'.txt')
    G = build_networkx_graph(folder_name + '/' + file_names[i]+'.txt')
    for s in range(len(GD_OPTIONS)):
     if len(edge_list)>edge_threshold:
      NUM_ITERATIONS = iterations_large_graph
      GRADIENT_DESCENT_ITERATIONS = gd_iter_large_graph
      K_start = -3
      K_end = 3
      layout = ['neato', 'sfdp', 'random', 'random', 'random']
      NUM_RUNS = len(layout)
      layout_number = ['0', '0', '0', '1', '2']
     else:
      NUM_ITERATIONS = iterations_small_graph
      K_start = -5
      K_end = 5
      layout = ['neato', 'neato', 'neato', 'neato', 'neato', 'sfdp', 'sfdp', 'sfdp', 'sfdp', 'sfdp', 'random', 'random', 'random', 'random', 'random']
      NUM_RUNS = len(layout)
      layout_number = ['0', '1', '2', '3', '4', '0', '1', '2', '3', '4', '0', '1', '2', '3', '4']
     K_start_str = str(K_start)
     if K_start<0:
      K_start_str = 'N'+str(-K_start)
     K_end_str = str(K_end)
     if K_end<0:
      K_end_str = 'N'+str(-K_end)
     for r in range(0,NUM_RUNS):
      for K in range(K_start,K_end):
       K_start_str = str(K)
       if K<0:
        K_start_str = 'N'+str(-K)
       K_end_str = str(K+1)
       if K+1<0:
        K_end_str = 'N'+str(-(K+1))
       file_ext = 'W_'+str(W)+'_NORM_'+str(n)+'_K_'+K_start_str+'_'+K_end_str+'_STRAT_'+GD_OPTIONS[s]+'_'+layout[r]+'_'+layout_number[r]
       if not os.path.exists(folder_name + '/' + file_names[i] + '_ang_'+file_ext+'.npy'):
        continue
       MIN_ANGLES = np.load(folder_name + '/' + file_names[i] + '_ang_'+file_ext+'.npy')
       X_new = np.load(folder_name + '/' + file_names[i] + '_xy_'+file_ext+'.npy')
       print(folder_name + '/' + file_names[i] + '_xy_'+file_ext+'.npy')
       print_log(folder_name + '/' + file_names[i] + '_xy_'+file_ext+'.npy')
       for it in range(NUM_ITERATIONS):
        for gd_it in range(GRADIENT_DESCENT_ITERATIONS):
         #print(MIN_ANGLES.shape)
         #print(MIN_ANGLES)
         #print(str(W))
         #print(str(K-K_start))
         #print(str(nr))
         #print('X_new.shape:', X_new.shape)

         tmp_rnd = random.randint(1, sample_param_1)
         if tmp_rnd>sample_param_2:continue

         curr_x = X_new[W-W_start][0][it][gd_it]
         #print('curr_x:', curr_x)
         curr_angle = find_min_angle(G, curr_x)
         if max_min_angle[i]<curr_angle:
          max_min_angle[i] = curr_angle
          write_as_txt(folder_name + '/grad_desc' + str(i+1) + '.txt', edge_list, curr_x[:,0], curr_x[:,1])
          txt_to_json(folder_name + '/grad_desc' + str(i+1) + '.txt', folder_name + '/grad_desc' + str(i+1) + '.json')

 write_array(max_min_angle, folder_name + '/grad_desc_max_min_angle.txt')
 print(max_min_angle)
 print_log(str(max_min_angle))

def print_log(s):
 global folder
 log_file = open(folder+'print_log.txt', 'a')
 log_file.write(s+'\n')
 log_file.close()


#check_grad_desc(16, 100)
#check_grad_desc(10, 100)

#check_grad_desc(11, 100, '../graphs/input_angle/')
#check_grad_desc(16, 100, '../graphs/input_angle_17/')
#check_grad_desc_ncr(11, 100, '../graphs/input_crossing/')
#check_grad_desc_ncr(16, 100, '../graphs/input_crossing_17/')

#check_grad_desc(11, 100, '../graphs/input_angle_vanila/')
#check_grad_desc(14, 100, '../graphs/input_angle_new_GDs/', 30, 2)
#check_grad_desc(14, 1650, '../graphs/input_angle_mid_dense/', 30, 2)
#check_grad_desc(16, 1650, '../graphs/input_angle_mid_dense_17', 30, 2)
#check_grad_desc(16, 100, '../graphs/input_angle_new_GDs_17/', 30, 2)
#check_grad_desc(9, 10, 100, 'input_angle_10_18/', 30, 3, 100, 100)

import sys
if len(sys.argv)!=7:
 print('Usage: python3 check_store_X.py graph_id folder iterations_large_graph gd_iter_large_graph sample_param_1 sample_param_2')
 quit()
graph_id = int(sys.argv[1])
folder = sys.argv[2]
if folder[len(folder)-1]!='/':
 folder = folder + '/'
iterations_large_graph = int(sys.argv[3])
gd_iter_large_graph = int(sys.argv[4])
sample_param_1 = int(sys.argv[5])
sample_param_2 = int(sys.argv[6])

log_file = open(folder+'print_log.txt', 'w')
log_file.close()

check_grad_desc(graph_id-1, graph_id, 100, folder, 30, iterations_large_graph, 100, gd_iter_large_graph, sample_param_1, sample_param_2)


