qsub -J 1-96 -N edge_crossings -o log_files_dodec_and_twin/edge_crossings.out -e log_files_dodec_and_twin/edge_crossings.err -V edge_crossings_community_crossing.sh
qsub -J 97-192 -N edge_crossings -o log_files_dodec_and_twin/edge_crossings.out -e log_files_dodec_and_twin/edge_crossings.err -V edge_crossings_community_crossing.sh
