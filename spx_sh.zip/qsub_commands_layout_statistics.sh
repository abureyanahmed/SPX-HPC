export folder_name=input18
export number_of_graphs=16
export number_of_drawings=5
export drawing_start=1
qsub -N layout_statistics_11 -o log_files/layout_statistics_1_6.out -e log_files/layout_statistics_1_6.err -V layout_statistics.sh
export folder_name=input18
export number_of_graphs=16
export number_of_drawings=5
export drawing_start=6
qsub -N layout_statistics_11 -o log_files/layout_statistics_6_11.out -e log_files/layout_statistics_6_11.err -V layout_statistics.sh
export folder_name=input18
export number_of_graphs=16
export number_of_drawings=5
export drawing_start=11
qsub -N layout_statistics_11 -o log_files/layout_statistics_11_16.out -e log_files/layout_statistics_11_16.err -V layout_statistics.sh
export folder_name=input18
export number_of_graphs=16
export number_of_drawings=5
export drawing_start=16
qsub -N layout_statistics_11 -o log_files/layout_statistics_16_21.out -e log_files/layout_statistics_16_21.err -V layout_statistics.sh
export folder_name=input18
export number_of_graphs=16
export number_of_drawings=5
export drawing_start=21
qsub -N layout_statistics_11 -o log_files/layout_statistics_21_26.out -e log_files/layout_statistics_21_26.err -V layout_statistics.sh
export folder_name=input18
export number_of_graphs=16
export number_of_drawings=5
export drawing_start=26
qsub -N layout_statistics_11 -o log_files/layout_statistics_26_31.out -e log_files/layout_statistics_26_31.err -V layout_statistics.sh
export folder_name=input18
export number_of_graphs=16
export number_of_drawings=5
export drawing_start=31
qsub -N layout_statistics_11 -o log_files/layout_statistics_31_36.out -e log_files/layout_statistics_31_36.err -V layout_statistics.sh
export folder_name=input18
export number_of_graphs=16
export number_of_drawings=5
export drawing_start=36
qsub -N layout_statistics_11 -o log_files/layout_statistics_36_41.out -e log_files/layout_statistics_36_41.err -V layout_statistics.sh
export folder_name=input18
export number_of_graphs=16
export number_of_drawings=5
export drawing_start=41
qsub -N layout_statistics_11 -o log_files/layout_statistics_41_46.out -e log_files/layout_statistics_41_46.err -V layout_statistics.sh
export folder_name=input18
export number_of_graphs=16
export number_of_drawings=5
export drawing_start=46
qsub -N layout_statistics_11 -o log_files/layout_statistics_46_51.out -e log_files/layout_statistics_46_51.err -V layout_statistics.sh
