export NORMALIZE=0
export FILE_NAME_PREFIX=er_50_0.1
export OUTPUT_FOLDER=profile_smart_algorithm
qsub -N edge_crossings -o log_files_angle/edge_crossingser_50_0.1.out -e log_files_angle/edge_crossingser_50_0.1.err -V edge_crossings_angle.sh
export NORMALIZE=0
export FILE_NAME_PREFIX=er_50_0.2
export OUTPUT_FOLDER=profile_smart_algorithm
qsub -N edge_crossings -o log_files_angle/edge_crossingser_50_0.2.out -e log_files_angle/edge_crossingser_50_0.2.err -V edge_crossings_angle.sh
export NORMALIZE=0
export FILE_NAME_PREFIX=er_100_0.1
export OUTPUT_FOLDER=profile_smart_algorithm
qsub -N edge_crossings -o log_files_angle/edge_crossingser_100_0.1.out -e log_files_angle/edge_crossingser_100_0.1.err -V edge_crossings_angle.sh
export NORMALIZE=0
export FILE_NAME_PREFIX=er_100_0.2
export OUTPUT_FOLDER=profile_smart_algorithm
qsub -N edge_crossings -o log_files_angle/edge_crossingser_100_0.2.out -e log_files_angle/edge_crossingser_100_0.2.err -V edge_crossings_angle.sh
export NORMALIZE=0
export FILE_NAME_PREFIX=er_150_0.1
export OUTPUT_FOLDER=profile_smart_algorithm
qsub -N edge_crossings -o log_files_angle/edge_crossingser_150_0.1.out -e log_files_angle/edge_crossingser_150_0.1.err -V edge_crossings_angle.sh
export NORMALIZE=0
export FILE_NAME_PREFIX=er_150_0.2
export OUTPUT_FOLDER=profile_smart_algorithm
qsub -N edge_crossings -o log_files_angle/edge_crossingser_150_0.2.out -e log_files_angle/edge_crossingser_150_0.2.err -V edge_crossings_angle.sh
export NORMALIZE=0
export FILE_NAME_PREFIX=er_200_0.1
export OUTPUT_FOLDER=profile_smart_algorithm
qsub -N edge_crossings -o log_files_angle/edge_crossingser_200_0.1.out -e log_files_angle/edge_crossingser_200_0.1.err -V edge_crossings_angle.sh
export NORMALIZE=0
export FILE_NAME_PREFIX=er_200_0.2
export OUTPUT_FOLDER=profile_smart_algorithm
qsub -N edge_crossings -o log_files_angle/edge_crossingser_200_0.2.out -e log_files_angle/edge_crossingser_200_0.2.err -V edge_crossings_angle.sh
