export OUTPUT_FOLDER=crossing_min_random_drawing/north
export FILE_NAME_PREFIX=g.61.3
export W_start=1
export W_end=2
export K_start=-3
export K_end=3
export NUM_RUNS=6
export num_iterations=3
export NORMALIZE=0
export OUTPUT_FILE_EXT=W_1_NORM_0_K_N3_3
qsub -N edge_crossings_W_1_NORM_0_K_N3_3 -o log_files_north/edge_crossings_g.61.3_W_1_NORM_0_K_N3_3.out -e log_files_north/edge_crossings_g.61.3_W_1_NORM_0_K_N3_3.err -V edge_crossings_marcel.sh
